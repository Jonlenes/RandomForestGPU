#ifndef DATA_H
#define DATA_H

#include "Util.h"


using namespace std;

class Data {
public:
    double *features;

	int featureSize;
    int samplesSize;
    
public:
    Data();
    ~Data();

    void read(const string &filename);

    double getFeature(int sampleIndex, int featureIndex);

    int getSampleSize();

    int getFeatureSize();

};

#endif //DATA_H
