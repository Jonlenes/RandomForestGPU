#ifndef UTIL_H
#define UTIL_H

#include <sstream>
#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

namespace
{

	/*
	* Load a file.
	*/
    ifstream *load_file(const string &filename) {
        ifstream *file = new ifstream(filename);
        if (!*file)
        {
            cout << "File '" << filename << "' not found.\n";
            exit(-1);
        }
        return file;
    }


	/*
    * Close file and free memory
	*/
    void close_file(ifstream *file) {
        file->close();
        delete file;
    }


	/*
	* Return index of max value
	*/
    int argMax(double *v, int size){
        int indexMax = 0;
        for (int i = 1; i < size; ++i) {
            if (v[i] > v[indexMax])
                indexMax = i;
        }

        return indexMax;

        //C++ Version: return distance(v.begin(), max_element(v.begin(), v.end()));
    }


	/*
	* Read a list of double in file
	*/
    double *getArray(ifstream &file, int size) {
        double *vet = new double[size];
        double value;
        for (int i = 0; i < size; ++i) {
            file >> value;
            vet[i] = value;
        }
        return vet;
    }


    /*
    * Allocate a matrix in memory
    */
    double **allocate(int l, int c) {
        double **mat = new double*[ l ];
        for (int i = 0; i < l; ++i) {
            mat[i] = new double[c];
            memset(mat[i], 0, sizeof(double) * c);
        }
        return mat;
    }


    /*
    * Release memory
    */
    void free(double **mat, int l) {
        for (int i = 0; i < l; ++i)
            delete [] mat[i];
        delete [] mat;
    }


}

#endif // UTIL_H
