#ifndef CUDAPROCESS_H
#define CUDAPROCESS_H

#include "DecisionTree.h"
#include "Data.h"

#include <cuda_runtime_api.h>
#include <cuda.h>

namespace {

/*
* Walk in the to find the leaf
*/
__global__
void _CUDA_DT_computePredict(Node *nodes, double *values, double *features, int sampleIndex, int featureSize, int nClasses, double *out) {
    int index = 0;
    while (nodes[index].left != -1) {
        // Check if the feature is bigger than threshold
        if ( features[ sampleIndex * featureSize + nodes[index].featureIndex ] > nodes[index].threshold) {
            index = nodes[index].right;
        } else {
            index = nodes[index].left;
        }
    }
    
    // Copy value
    for (int i = 0; i < nClasses; ++i)
        out[i] = values[index * nClasses + i];
}


/*
* Compute the votes
*/
void CUDA_DT_predict(DecisionTree &dt, Data &data, double **results, int nClasses) {

    /*
     * Here, we need copy the tree and data to GPU.
     * All data will be copied. If the GPU memory is
     * too small or you have too many data, you should
     * consider a better way to do this.
     *
     *
     * There are many ways you can parallelize this GPU code.
     * Using this idea here to copy the data to the GPU you
     * can easily modify to whatever you need.
     */

    /************************** Copy tree to GPU **************************/
    Node *nodes = nullptr;
    double *values = nullptr;
    double *features = nullptr;
    size_t size = 0;

    // Allocate and copy nodes
    size = dt.nodeCount * sizeof(Node);
    cudaMalloc((void **) &nodes, size);
    cudaMemcpy(nodes, dt.nodes, size, cudaMemcpyHostToDevice);

    //Copy values
    size = dt.nodeCount * nClasses * sizeof(double);
    cudaMalloc((void **) &values, size);
    cudaMemcpy(values, dt.nodeValues, size, cudaMemcpyHostToDevice);

    /* Copy data to GPU */
    size = data.featureSize * data.samplesSize * sizeof(double);
    cudaMalloc((void **) &features, size);
    cudaMemcpy(features, data.features, size, cudaMemcpyHostToDevice);


    for (int i = 0; i < data.getSampleSize(); i++) {
        double *pred_tree_CUDA = nullptr;
        size =  nClasses * sizeof(double);
        cudaMalloc((void **) &pred_tree_CUDA, size);
        
        // Performs on GPU (serially)
        _CUDA_DT_computePredict <<< 1, 1 >>> (nodes, values, features, i, data.featureSize, nClasses, pred_tree_CUDA);

        //Copy result back
        double *pred_tree = new double[nClasses];
        size =  nClasses * sizeof(double);
        cudaMemcpy(pred_tree, pred_tree_CUDA, size, cudaMemcpyDeviceToHost);

        int cls = argMax(pred_tree, nClasses);
        results[i][cls] += 1;

        delete [] pred_tree;
        cudaFree( pred_tree_CUDA );
    }

    cudaFree(nodes);
    cudaFree(values);
    cudaFree(features);
}

}

#endif // CUDAPROCESS_H
