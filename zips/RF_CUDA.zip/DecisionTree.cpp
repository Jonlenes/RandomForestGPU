#include "DecisionTree.h"


DecisionTree::DecisionTree() {
    nodes = nullptr;
    nodeValues = nullptr;
}


/*
 * Load RF model
 */
void DecisionTree::loadModel(ifstream &file, int nClasses) {
    // Number of nodes of this tree
    file >> nodeCount;

    // Read informations about the tree
    double *children_left = getArray(file, nodeCount);
    double *children_right = getArray(file, nodeCount);
    double *feature = getArray(file, nodeCount);
    double *threshold = getArray(file, nodeCount);

    // Create all nodes
    nodes = new Node[nodeCount];
    nodeValues = new double[nodeCount * nClasses];

    for (int i = 0; i < nodeCount; ++i) {
        nodes[i].featureIndex = int(feature[i]);
        nodes[i].threshold = threshold[i];
        double *values = getArray(file, nClasses);
        for (int j = 0; j < nClasses; ++j)
            nodeValues[i * nClasses + j] = values[j];
        delete [] values;
    }

    // Build the tree
    for (int i = 0; i < nodeCount; ++i) {
        if (int(children_left[i]) != -1)
            nodes[i].left = int(children_left[i]);

        if (int(children_right[i]) != -1)
            nodes[i].right = int(children_right[i]);
    }

    // Free memory
    delete [] children_left;
    delete [] children_right;
    delete [] feature;
    delete [] threshold;

}


DecisionTree::~DecisionTree() {
    if (nodes) delete [] nodes;
    if (nodeValues) delete [] nodeValues;
}
