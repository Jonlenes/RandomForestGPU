#include "DecisionTree.h"


DecisionTree::DecisionTree() {
    nodes = nullptr;
    root = nullptr;
}


/*
 * Load RF model
 */
void DecisionTree::loadModel(ifstream &file, int nClasses) {
    // Number of nodes of this tree
    file >> nodeCount;

    // Read informations about the tree
    double *children_left = getArray(file, nodeCount);
    double *children_right = getArray(file, nodeCount);
    double *feature = getArray(file, nodeCount);
    double *threshold = getArray(file, nodeCount);

    // Create all nodes
    nodes = new Node[nodeCount];
    for (int i = 0; i < nodeCount; ++i) {
        nodes[i].featureIndex = feature[i];
        nodes[i].threshold = threshold[i];
        nodes[i].value = getArray(file, nClasses);
    }

    // Build the tree
    for (int i = 0; i < nodeCount; ++i) {
        if (int(children_left[i]) != -1)
            nodes[i].left = &nodes[ int(children_left[i]) ];

        if (int(children_right[i]) != -1)
            nodes[i].right = &nodes[ int(children_right[i]) ];
    }

    // First node is the root
    this->root = &nodes[ 0 ];

    // Free memory
    delete [] children_left;
    delete [] children_right;
    delete [] feature;
    delete [] threshold;

}


DecisionTree::~DecisionTree() {
    if (nodes) {
        for (int i = 0; i < nodeCount; ++i) {
            delete [] nodes[i].value;
        }
        delete [] nodes;
    }
}

/*
* Walk in the to find the right leaf
*/
double* DecisionTree::computePredict(int sampleIndex, Data &data) {
    Node *node = root;
    while (node->left) {
		// Check if the feature is bigger than threshold
        if (data.getFeature(sampleIndex, node->featureIndex) > node->threshold) {
            node = node->right;
        } else {
            node = node->left;
        }
    }
    return node->value;
}


/*
* Compute the votes
*/
void DecisionTree::predict(Data &data, double **results, int nClasses) {
    for (int i = 0; i < data.getSampleSize(); i++) {
        double *pred_tree = computePredict(i, data);
        int cls = argMax(pred_tree, nClasses);
        results[i][cls] += 1;
    }
}
