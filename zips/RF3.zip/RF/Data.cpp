#include "Data.h"


Data::Data() {
    this->featureSize = -1;
}


Data::~Data() {
    free(features, samplesSize);
}


/*
* Read the data
*/
void Data::read(const string &filename) {
    ifstream &file = *load_file(filename);
    string str;
    double number;

    file >> samplesSize;
    file >> featureSize;

    features = allocate(samplesSize, featureSize);

    for (int i = 0; i < samplesSize; ++i) {
        for (int j = 0; j < featureSize; j++) {
            file >> number;
            features[i][j] = number;
        }
    }

    close_file(&file);
}


/*
* Return a feature
*/
double Data::getFeature(int sampleIndex, int featureIndex) {
    return features[sampleIndex][featureIndex];
}


/*
* Number of sample
*/
int Data::getSampleSize() {
    return samplesSize;
}


/*
* Number de feaures
*/
int Data::getFeatureSize() {
    return featureSize;
}
