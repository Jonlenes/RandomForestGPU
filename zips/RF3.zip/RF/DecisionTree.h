
#ifndef DECISIONTREE_H
#define DECISIONTREE_H

#include "Data.h"
#include <memory>
#include <functional>
#include <utility>
#include <cmath>
#include <fstream>

using namespace std;


class DecisionTree {
private:
	// Node of the tree
    struct Node {
        int featureIndex;
        Node *left;
        Node *right;
        double threshold;
        double* value;

        Node() {
            left = nullptr;
            right = nullptr;
        }
    };

    Node *root;
    Node *nodes;
    int nodeCount;

public:
    DecisionTree();
    ~DecisionTree();

    double *computePredict(int sampleIndex, Data &data);
    void predict(Data &data, double **results, int nClasses);
    void loadModel(ifstream &file, int nClasses);
};

#endif
