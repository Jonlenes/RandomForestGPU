#include <iostream>
#include "RandomForest.h"

using namespace std;

int main()
{
	// Load RF from file
    printf("Loading the model...\n");
    RandomForest randomForest("C:/Users/Jonlenes/Google Drive/Projects/Project - Random Forest/RF/data/model.rf");

    // 1000 samples and 20 features
    printf("Loading the data...\n");
    Data data;
    data.read("C:/Users/Jonlenes/Google Drive/Projects/Project - Random Forest/RF/data/X_test.data");

	// Predict
    printf("Predict...\n");
    int *classes = randomForest.predict(data);

	// Save result in file
    ofstream pred_file("C:/Users/Jonlenes/Google Drive/Projects/Project - Random Forest/RF/data/cpp.pred");
    for (int i = 0; i < data.getSampleSize(); ++i) {
        pred_file << classes[i];
        pred_file << endl;
    }

    // Free memory
    delete [] classes;

    return 0;
}
