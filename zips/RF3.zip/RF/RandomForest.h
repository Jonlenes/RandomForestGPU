#ifndef RANDOMFOREST_H
#define RANDOMFOREST_H

#include "DecisionTree.h"
#include "Data.h"
#include "Util.h"
#include <string.h>

class RandomForest {
private:
    DecisionTree *decisionTrees;
    int nEstimators;
    int nClasses;

public:
    RandomForest(const string &path);
    ~RandomForest();

    int *predict(Data &data);
};

#endif //RANDOMFOREST_H
