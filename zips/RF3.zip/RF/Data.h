#ifndef DATA_H
#define DATA_H

#include "Util.h"


using namespace std;

class Data {
private:
    double **features;

	int featureSize = 0;
    int samplesSize = 0;
    
public:
    Data();
    ~Data();

    void read(const string &filename);

    double getFeature(int sampleIndex, int featureIndex);

    int getSampleSize();

    int getFeatureSize();

};

#endif //DATA_H
