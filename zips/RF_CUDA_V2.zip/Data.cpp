#include "Data.h"


Data::Data() {
    featureSize = 0;
    samplesSize = 0;
    this->featureSize = -1;
    features = nullptr;
}


Data::~Data() {
    if (features) delete [] features;
}


/*
* Read the data
*/
void Data::read(const string &filename) {
    ifstream &file = *load_file(filename);
    string str;
    double number;

    file >> samplesSize;
    file >> featureSize;

    features = new double[samplesSize * featureSize];

    for (int i = 0; i < samplesSize; ++i) {
        for (int j = 0; j < featureSize; j++) {
            file >> number;
            features[i * featureSize + j] = number;
        }
    }

    close_file(&file);
}


/*
* Return a feature
*/
double Data::getFeature(int sampleIndex, int featureIndex) {
    return features[sampleIndex * featureSize + featureIndex];
}


/*
* Number of sample
*/
int Data::getSampleSize() {
    return samplesSize;
}


/*
* Number de feaures
*/
int Data::getFeatureSize() {
    return featureSize;
}
