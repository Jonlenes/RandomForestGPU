#include <iostream>
#include <time.h>
#include "RandomForest.h"

using namespace std;

int main()
{
	// Load RF from file
    printf("Loading the model...\n");
    RandomForest randomForest("./data/model.rf");

    // Reading the datas
    printf("Loading the data...\n");
    Data data;
    data.read("./data/X_test.data");

	// Predict
    printf("Predict...\n");
    
    const clock_t beginTime = clock();
    int *classes = randomForest.predict(data);
    cout << "Predict time: " << float( clock () - beginTime ) /  CLOCKS_PER_SEC << "s" << endl;

	// Save result in file
    ofstream pred_file("./data/cpp.pred");
    for (int i = 0; i < data.getSampleSize(); ++i) {
        pred_file << classes[i];
        pred_file << endl;
    }

    // Free memory
    delete [] classes;

    return 0;
}
