#ifndef CUDAPROCESS_H
#define CUDAPROCESS_H

#include "DecisionTree.h"
#include "Data.h"

#include <cuda_runtime_api.h>
#include <cuda.h>


// Max that I want to use in my GPU
// You can calculate this values on execution time
const static int MAX_N_BLOCK = 1024;
const static int MAX_N_THREADS = 1024;


// The real number of threads and blocks basead on # samples
static int nThreads = MAX_N_THREADS;    // Using the # max of threads
static int nBlocks = MAX_N_BLOCK;       // Using the # max of blocks
static int nProcess = 1;                // One sample by thread


namespace {

    /*
     * Compute the the number of threads, blocks and # samples
     * per thread based on MAX_N_BLOCK and MAX_N_THREADS
     */
    __host__ void computeBlocksThreads(int n) {
        if (n < nThreads) {
            nBlocks = 1;
            nThreads = n;
        } else if ( n < (nThreads * nBlocks) )
            nBlocks = n / nThreads + 1;
        else
            nProcess = n / (nThreads * nBlocks) + 1;
        
        /*std::cout << "\tPredict on GPU\n";
        std::cout << "\t\tN blocks: " << nBlocks << "\n";
        std::cout << "\t\tN threads: " << nThreads << "\n";
        std::cout << "\t\tN Samples per thread: " << nProcess << "\n";*/
    }



    /*
    * Return index of max value (Run on host or device)
    */
    __host__ __device__ int argMax(double *v, int size){
        int indexMax = 0;
        for (int i = 1; i < size; ++i) {
            if (v[i] > v[indexMax])
                indexMax = i;
        }

        return indexMax;
    }


    /*
    * Walk in the to find the leaf
    */
    __global__
    void _DDT_computePredict(Node *nodes, double *values, double *features, int nFeatures,
                             int nClasses, int nProcess, int nSamples, int *out) {

        // Begin and end samples process
        int sampleBegin = (blockIdx.x * blockDim.x + threadIdx.x) * nProcess;
        int sampleEnd = sampleBegin + nProcess;

        // Check # Samples
        if (sampleEnd > nSamples) sampleEnd = nSamples;

        // Process nProcess by thread
        for ( int sampleIndex = sampleBegin; sampleIndex < sampleEnd; ++sampleIndex) {
            int index = 0;
            while (nodes[index].left != -1) {
                // Check if the feature is bigger than threshold
                if ( features[ sampleIndex * nFeatures + nodes[index].featureIndex ] > nodes[index].threshold) {
                    index = nodes[index].right;
                } else {
                    index = nodes[index].left;
                }
            }

            // Compute votes
            out[sampleIndex] = out[sampleIndex] = argMax(values + (index * nClasses), nClasses);
        }
    }


    /*
     * Allocate GPU memory and copy data (if not null).
     */
    void D_allocate(void **m, size_t size, void *data=nullptr) {
        cudaMalloc(m, size);
        if (data)
            cudaMemcpy(*m, data, size, cudaMemcpyHostToDevice);
    }


    /*
    * Compute the votes
    * DDT - Device Deciosion Tree
    */
    void DDT_predict(DecisionTree &dt, double *&D_features, int samplesSize, int featureSize, double **results, int nClasses) {

        /************************** Copy tree to GPU **************************/
        size_t size = 0;

        // Allocate and copy nodes
        Node *D_nodes = nullptr;
        double *D_values = nullptr;
        int *D_pred_tree = nullptr;

        // Copy tree to GPU
        D_allocate((void**)&D_nodes, dt.nodeCount * sizeof(Node), dt.nodes);
        D_allocate((void**)&D_values, dt.nodeCount * nClasses * sizeof(double), dt.nodeValues);
        D_allocate((void**)&D_pred_tree, samplesSize * sizeof(int));
        /************************** Copy tree to GPU **************************/

        // Performs on GPU (parallel - # threads = # samples)
        _DDT_computePredict <<< nBlocks, nThreads >>> (D_nodes, D_values, D_features, featureSize,
                                                       nClasses, nProcess, samplesSize, D_pred_tree);

        //Copy result back
        int *pred_cls = new int[samplesSize];
        size = samplesSize * sizeof(int);
        cudaMemcpy(pred_cls, D_pred_tree, size, cudaMemcpyDeviceToHost);

        // Save results
        for (int i = 0; i < samplesSize; i++)
            results[i][ pred_cls[i] ] += 1;

        // Free host memory
        delete [] pred_cls;

        // Free device memory
        cudaFree( D_nodes );
        cudaFree( D_values );
        cudaFree( D_pred_tree );
    }
}

#endif // CUDAPROCESS_H
