
#ifndef DECISIONTREE_H
#define DECISIONTREE_H

#include "Node.h"
#include "Data.h"
#include <memory>
#include <functional>
#include <utility>
#include <cmath>
#include <fstream>

using namespace std;

class DecisionTree {
public:

    Node *nodes;
    /* The values had to leave the
     * Node structure in order to be copied to the GPU. */
    double *nodeValues;
    int nodeCount;

public:
    DecisionTree();
    ~DecisionTree();

    void loadModel(ifstream &file, int nClasses);
};

#endif
