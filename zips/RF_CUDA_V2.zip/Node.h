#ifndef NODE_H
#define NODE_H

// Node of the tree
struct Node {
    int featureIndex;
    int left;
    int right;
    double threshold;

    Node() {
        left = -1;
        right = -1;
    }
};

#endif // NODE_H
