#include "RandomForest.h"
#include "DProcess.cpp"


RandomForest::RandomForest(const string &path)
{
	// Load the file
    ifstream &file = *load_file(path);
    
	// Number of trees and classes
    file >> nEstimators;
    file >> nClasses;

    decisionTrees = new DecisionTree[nEstimators];

	// Creat the trees
    for (int i = 0; i < nEstimators; ++i)
        decisionTrees[i].loadModel(file, nClasses);

    close_file(&file);
}


RandomForest::~RandomForest()
{
    if (decisionTrees) 
        delete []decisionTrees;
}


int *RandomForest::predict(Data &data) {
    int nSamples = data.getSampleSize();

    // Alocate memory
    double **all_pred = allocate(nSamples, nClasses);    
    double *D_features = nullptr;

    // Copy all data the to GPU
    D_allocate((void**)&D_features, data.featureSize * nSamples * sizeof(double), data.features);

    // Compute # Blocks and Threads 
    computeBlocksThreads(data.samplesSize);

    // Predict in all the trees on GPU
    for (int i = 0; i < nEstimators; i++)
        DDT_predict(decisionTrees[i], D_features, nSamples, data.featureSize, all_pred, nClasses);
	
	// Compute votes
    int *classes = new int[nSamples];
    for (int i = 0; i < nSamples; ++i)
        classes[i] = argMax(all_pred[i], nClasses);

    // Free memory
    free(all_pred, nSamples);
    cudaFree( D_features );

    return classes;
}
